#include <iostream>
using namespace std;
#define PI 3.14

int main() {

	int r;
	cin >> r;

	cout << PI * r * r << endl;

}

