#include <iostream>
using namespace std;
#include "Vehicle.cpp"
#include "Car.cpp"
#include "HondaCity.cpp"


int main() {

	HondaCity h(4, 5);
	
	
	//	Vehicle v;

	//v.color = "Blue";
	// v.maxSpeed = 100;
	// v.numTyres = 4;



//	Car c(5);
	
	
	
	//c.color = "Black";
//	c.numTyres = 4;
	// c.numGears = 5;


}

