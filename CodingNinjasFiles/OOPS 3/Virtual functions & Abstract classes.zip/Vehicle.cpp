class Vehicle {
	public :
		string color;

		// Pure virtual fn
	virtual void print() = 0;


};

