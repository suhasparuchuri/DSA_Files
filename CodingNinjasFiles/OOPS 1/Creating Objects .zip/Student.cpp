class Student {

	public :

	int rollNumber;
	
	private :
	int age;
};


