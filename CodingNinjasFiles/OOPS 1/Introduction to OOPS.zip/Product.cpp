class Product {
	int id;
	int weight;
	char name[100];
};
