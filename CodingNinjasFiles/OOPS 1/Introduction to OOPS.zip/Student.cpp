class Student {
	int rollNumber;
	int age;
};


